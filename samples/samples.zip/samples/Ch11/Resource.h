//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by httpmt.rc
//
#define IDD_MAINWND                     1
#define IDB_HTTP                        104
#define IDI_APP                         105
#define IDD_SERVINFO                    106
#define IDC_START_STOP                  1002
#define IDC_LIST                        1004
#define IDC_RATE                        1005
#define IDC_RECEIVED                    1006
#define IDC_TRANSFERRED                 1007
#define IDC_CONNECTIONS                 1008
#define IDC_PORT                        1009
#define IDC_ROOTDIR                     1010
#define IDC_EVENTLOG                    1011
#define IDS_HTTPERROR_NOTFOUND          11005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
