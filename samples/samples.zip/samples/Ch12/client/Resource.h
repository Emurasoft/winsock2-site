//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by echoclnt.rc
//
#define IDD_MAINWND                     107
#define IDI_ICON2                       110
#define IDI_ICON1                       111
#define IDC_LIST1                       1012
#define IDC_ECHOS                       1012
#define IDC_SOCKETS                     1013
#define IDC_BYTES                       1014
#define IDC_SEND                        1015
#define IDC_HOSTNAME                    1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
